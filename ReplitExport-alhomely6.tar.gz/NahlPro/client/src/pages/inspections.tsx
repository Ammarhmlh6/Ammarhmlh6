import { useState } from "react";
import InspectionCard from "@/components/InspectionCard";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Plus } from "lucide-react";

export default function Inspections() {
  const [selectedHive, setSelectedHive] = useState("all");

  const mockInspections = [
    {
      id: '1',
      hive: 'خلية 1',
      date: 'منذ 3 أيام - 15 نوفمبر 2025',
      queenPresent: true,
      colonyStrength: 'قوية' as const,
      broodPresent: true,
      honeyAmount: 'ممتلئة' as const,
      actions: 'إضافة عسلة جديدة للتوسع'
    },
    {
      id: '2',
      hive: 'خلية 3',
      date: 'منذ أسبوع - 10 نوفمبر 2025',
      queenPresent: false,
      colonyStrength: 'ضعيفة' as const,
      broodPresent: false,
      honeyAmount: 'قليلة' as const,
      issues: 'الملكة غائبة، لا توجد حضنة',
      actions: 'إدخال ملكة جديدة، تغذية بعجينة السكر'
    },
    {
      id: '3',
      hive: 'خلية 2',
      date: 'منذ أسبوع - 10 نوفمبر 2025',
      queenPresent: true,
      colonyStrength: 'متوسطة' as const,
      broodPresent: true,
      honeyAmount: 'متوسطة' as const,
      actions: 'تغذية بمحلول سكري'
    },
    {
      id: '4',
      hive: 'خلية 1',
      date: 'منذ أسبوعين - 3 نوفمبر 2025',
      queenPresent: true,
      colonyStrength: 'قوية' as const,
      broodPresent: true,
      honeyAmount: 'متوسطة' as const,
    },
  ];

  const filteredInspections = selectedHive === 'all'
    ? mockInspections
    : mockInspections.filter(i => i.hive === selectedHive);

  return (
    <div className="container px-4 py-6 space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold">الفحوصات</h1>
          <p className="text-muted-foreground mt-1">
            سجل جميع الفحوصات الدورية
          </p>
        </div>
        <Button data-testid="button-add-inspection">
          <Plus className="h-5 w-5 ml-2" />
          إضافة فحص جديد
        </Button>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>تصفية حسب الخلية</CardTitle>
        </CardHeader>
        <CardContent>
          <Select value={selectedHive} onValueChange={setSelectedHive}>
            <SelectTrigger className="max-w-md" data-testid="select-filter-hive">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">جميع الخلايا</SelectItem>
              <SelectItem value="خلية 1">خلية 1</SelectItem>
              <SelectItem value="خلية 2">خلية 2</SelectItem>
              <SelectItem value="خلية 3">خلية 3</SelectItem>
              <SelectItem value="خلية 4">خلية 4</SelectItem>
            </SelectContent>
          </Select>
        </CardContent>
      </Card>

      <div className="grid gap-4 md:grid-cols-2">
        {filteredInspections.map((inspection) => (
          <div key={inspection.id} className="space-y-2">
            <h3 className="font-semibold text-lg">{inspection.hive}</h3>
            <InspectionCard {...inspection} />
          </div>
        ))}
      </div>

      {filteredInspections.length === 0 && (
        <div className="text-center py-12 text-muted-foreground">
          <p>لا توجد فحوصات مسجلة</p>
        </div>
      )}
    </div>
  );
}
