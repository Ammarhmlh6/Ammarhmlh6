import { useState } from "react";
import FeedingForm from "@/components/FeedingForm";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Calendar, Coffee } from "lucide-react";

export default function Feeding() {
  const [activeTab, setActiveTab] = useState("new");

  const mockFeedingHistory = [
    {
      id: '1',
      hive: 'خلية 1',
      type: 'عجينة السكر',
      quantity: 500,
      date: 'منذ يوم - 16 نوفمبر 2025',
      notes: 'تغذية روتينية'
    },
    {
      id: '2',
      hive: 'خلية 3',
      type: 'محلول سكري 2:1',
      quantity: 1000,
      date: 'منذ 3 أيام - 14 نوفمبر 2025',
      notes: 'تغذية شتوية مكثفة'
    },
    {
      id: '3',
      hive: 'جميع الخلايا',
      type: 'عجينة البروتين',
      quantity: 5000,
      date: 'منذ أسبوع - 10 نوفمبر 2025',
      notes: 'تغذية جماعية لتقوية الطوائف'
    },
  ];

  return (
    <div className="container px-4 py-6 space-y-6">
      <div>
        <h1 className="text-3xl font-bold">التغذية</h1>
        <p className="text-muted-foreground mt-1">
          إدارة وتتبع تغذية الخلايا
        </p>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full max-w-md grid-cols-2">
          <TabsTrigger value="new" data-testid="tab-new-feeding">
            تسجيل تغذية جديدة
          </TabsTrigger>
          <TabsTrigger value="history" data-testid="tab-feeding-history">
            سجل التغذية
          </TabsTrigger>
        </TabsList>

        <TabsContent value="new" className="space-y-6">
          <div className="grid gap-6 lg:grid-cols-2">
            <FeedingForm />
            
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Coffee className="h-6 w-6 text-primary" />
                  حاسبة المقادير
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="p-4 rounded-lg bg-muted/50 border">
                  <h3 className="font-semibold mb-3">عجينة السكر (1:1)</h3>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">سكر</span>
                      <span className="font-medium">1 كجم</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">ماء دافئ</span>
                      <span className="font-medium">500 مل</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">عسل (اختياري)</span>
                      <span className="font-medium">100 جم</span>
                    </div>
                  </div>
                </div>

                <div className="p-4 rounded-lg bg-muted/50 border">
                  <h3 className="font-semibold mb-3">محلول سكري 2:1 (للشتاء)</h3>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">سكر</span>
                      <span className="font-medium">2 كجم</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">ماء دافئ</span>
                      <span className="font-medium">1 لتر</span>
                    </div>
                  </div>
                </div>

                <div className="p-3 rounded-lg bg-primary/10 border border-primary/20 text-sm">
                  <p className="text-primary font-medium">نصيحة:</p>
                  <p className="text-muted-foreground mt-1">
                    استخدم محلول 1:1 في الربيع والصيف، ومحلول 2:1 في الخريف والشتاء
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="history" className="space-y-4">
          {mockFeedingHistory.map((feeding) => (
            <Card key={feeding.id} className="hover-elevate transition-all">
              <CardContent className="pt-6">
                <div className="flex items-start justify-between gap-4">
                  <div className="flex-1 space-y-2">
                    <div className="flex items-center gap-2">
                      <h3 className="font-semibold text-lg">{feeding.hive}</h3>
                      <Badge variant="outline" className="bg-primary/10 text-primary border-primary/20">
                        {feeding.type}
                      </Badge>
                    </div>
                    <div className="flex items-center gap-4 text-sm text-muted-foreground">
                      <div className="flex items-center gap-1">
                        <Calendar className="h-4 w-4" />
                        <span>{feeding.date}</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <Coffee className="h-4 w-4" />
                        <span>{feeding.quantity} جم/مل</span>
                      </div>
                    </div>
                    {feeding.notes && (
                      <p className="text-sm text-muted-foreground">
                        {feeding.notes}
                      </p>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </TabsContent>
      </Tabs>
    </div>
  );
}
