import { useQuery } from "@tanstack/react-query";
import type { Hive, Alert } from "@shared/schema";
import DashboardHero from "@/components/DashboardHero";
import DashboardStats from "@/components/DashboardStats";
import HiveCard from "@/components/HiveCard";
import AlertsList from "@/components/AlertsList";
import AddHiveDialog from "@/components/AddHiveDialog";
import { formatDistanceToNow } from "date-fns";
import { ar } from "date-fns/locale";

export default function Dashboard() {
  const { data: hives = [], isLoading: hivesLoading } = useQuery<Hive[]>({
    queryKey: ['/api/hives'],
  });

  const { data: alerts = [], isLoading: alertsLoading } = useQuery<Alert[]>({
    queryKey: ['/api/alerts'],
    queryFn: async () => {
      const response = await fetch('/api/alerts?unreadOnly=true');
      if (!response.ok) throw new Error('Failed to fetch alerts');
      return response.json();
    }
  });

  const { data: stats, isLoading: statsLoading } = useQuery<{
    totalHives: number;
    activeHives: number;
    alerts: number;
    expectedProduction: number;
  }>({
    queryKey: ['/api/dashboard/stats'],
  });

  const getQueenStatus = (hive: Hive): "موجودة" | "غائبة" | "جديدة" => {
    if (!hive.queenAge) return "غائبة";
    if (hive.queenAge <= 3) return "جديدة";
    return "موجودة";
  };

  const formatLastInspection = (hive: Hive) => {
    // TODO: Get actual last inspection date from inspections table
    return "لم يتم الفحص بعد";
  };

  const formatAlert = (alert: Alert) => {
    return {
      id: String(alert.id),
      type: alert.alertType as "urgent" | "warning" | "info",
      title: alert.title,
      message: alert.message,
      date: formatDistanceToNow(new Date(alert.createdAt), { 
        addSuffix: true,
        locale: ar 
      }),
    };
  };

  if (hivesLoading || statsLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <div className="text-lg">جار التحميل...</div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col gap-6">
      <DashboardHero />
      
      <div className="container px-4 space-y-6">
        <DashboardStats
          totalHives={stats?.totalHives || 0}
          activeHives={stats?.activeHives || 0}
          alerts={stats?.alerts || 0}
          expectedProduction={stats?.expectedProduction || 0}
        />

        <div className="grid gap-6 lg:grid-cols-3">
          <div className="lg:col-span-2 space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-2xl font-bold">خلاياي</h2>
              <AddHiveDialog />
            </div>
            
            {hives.length === 0 ? (
              <div className="text-center py-12 text-muted-foreground border rounded-lg">
                <p>لا توجد خلايا بعد. ابدأ بإضافة خلية جديدة!</p>
              </div>
            ) : (
              <div className="grid gap-4 md:grid-cols-2">
                {hives.slice(0, 6).map((hive) => (
                  <HiveCard
                    key={hive.id}
                    id={String(hive.id)}
                    name={hive.name}
                    type={hive.type}
                    frames={hive.frames}
                    queenStatus={getQueenStatus(hive)}
                    colonyStrength={hive.colonyStrength as "ضعيفة" | "متوسطة" | "قوية"}
                    lastInspection={formatLastInspection(hive)}
                    hasIssues={hive.colonyStrength === "ضعيفة"}
                    onView={() => console.log('View hive', hive.id)}
                    onEdit={() => console.log('Edit hive', hive.id)}
                  />
                ))}
              </div>
            )}
          </div>

          <div className="lg:col-span-1">
            <AlertsList alerts={alerts.map(formatAlert)} />
          </div>
        </div>
      </div>
    </div>
  );
}
