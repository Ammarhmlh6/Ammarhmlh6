import { useState } from "react";
import HiveCard from "@/components/HiveCard";
import AddHiveDialog from "@/components/AddHiveDialog";
import { Input } from "@/components/ui/input";
import { Search } from "lucide-react";

export default function Hives() {
  const [searchQuery, setSearchQuery] = useState("");

  const mockHives = [
    {
      id: '1',
      name: 'خلية 1',
      type: 'أمريكي - لانجستروث',
      frames: 10,
      queenStatus: 'موجودة' as const,
      colonyStrength: 'قوية' as const,
      lastInspection: 'منذ 3 أيام',
    },
    {
      id: '2',
      name: 'خلية 2',
      type: 'بلدي',
      frames: 8,
      queenStatus: 'جديدة' as const,
      colonyStrength: 'متوسطة' as const,
      lastInspection: 'منذ أسبوع',
      hasIssues: true,
    },
    {
      id: '3',
      name: 'خلية 3',
      type: 'كيني',
      frames: 12,
      queenStatus: 'غائبة' as const,
      colonyStrength: 'ضعيفة' as const,
      lastInspection: 'منذ أسبوعين',
      hasIssues: true,
    },
    {
      id: '4',
      name: 'خلية 4',
      type: 'أمريكي - لانجستروث',
      frames: 10,
      queenStatus: 'موجودة' as const,
      colonyStrength: 'قوية' as const,
      lastInspection: 'منذ يومين',
    },
    {
      id: '5',
      name: 'خلية 5',
      type: 'وارية',
      frames: 14,
      queenStatus: 'موجودة' as const,
      colonyStrength: 'قوية' as const,
      lastInspection: 'منذ 4 أيام',
    },
    {
      id: '6',
      name: 'خلية 6',
      type: 'دادان',
      frames: 11,
      queenStatus: 'موجودة' as const,
      colonyStrength: 'متوسطة' as const,
      lastInspection: 'منذ 5 أيام',
    },
  ];

  const filteredHives = mockHives.filter(hive =>
    hive.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    hive.type.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="container px-4 py-6 space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold">الخلايا</h1>
          <p className="text-muted-foreground mt-1">
            إجمالي {mockHives.length} خلية
          </p>
        </div>
        <AddHiveDialog />
      </div>

      <div className="relative max-w-md">
        <Search className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input
          placeholder="ابحث عن خلية..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="pr-10"
          data-testid="input-search-hives"
        />
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {filteredHives.map((hive) => (
          <HiveCard
            key={hive.id}
            {...hive}
            onView={() => console.log('View hive', hive.id)}
            onEdit={() => console.log('Edit hive', hive.id)}
          />
        ))}
      </div>

      {filteredHives.length === 0 && (
        <div className="text-center py-12 text-muted-foreground">
          <p>لا توجد نتائج للبحث</p>
        </div>
      )}
    </div>
  );
}
