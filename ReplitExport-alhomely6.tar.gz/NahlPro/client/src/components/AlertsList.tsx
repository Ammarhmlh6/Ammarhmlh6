import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { AlertTriangle, Bell, Info } from "lucide-react";

interface Alert {
  id: string;
  type: "urgent" | "warning" | "info";
  title: string;
  message: string;
  date: string;
}

interface AlertsListProps {
  alerts: Alert[];
}

export default function AlertsList({ alerts }: AlertsListProps) {
  const getAlertIcon = (type: Alert["type"]) => {
    switch (type) {
      case "urgent":
        return <AlertTriangle className="h-5 w-5 text-destructive" />;
      case "warning":
        return <Bell className="h-5 w-5 text-yellow-600 dark:text-yellow-400" />;
      case "info":
        return <Info className="h-5 w-5 text-blue-600 dark:text-blue-400" />;
    }
  };

  const getAlertBadge = (type: Alert["type"]) => {
    switch (type) {
      case "urgent":
        return (
          <Badge variant="destructive" className="text-xs">
            عاجل
          </Badge>
        );
      case "warning":
        return (
          <Badge variant="outline" className="text-xs bg-yellow-500/10 text-yellow-700 dark:text-yellow-400 border-yellow-500/20">
            تحذير
          </Badge>
        );
      case "info":
        return (
          <Badge variant="outline" className="text-xs bg-blue-500/10 text-blue-700 dark:text-blue-400 border-blue-500/20">
            معلومة
          </Badge>
        );
    }
  };

  if (alerts.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>التنبيهات</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8 text-muted-foreground">
            <Bell className="h-12 w-12 mx-auto mb-3 opacity-50" />
            <p>لا توجد تنبيهات في الوقت الحالي</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>التنبيهات</CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        {alerts.map((alert) => (
          <div
            key={alert.id}
            className="flex items-start gap-3 p-3 rounded-lg border hover-elevate transition-all"
            data-testid={`alert-${alert.id}`}
          >
            <div className="mt-0.5">{getAlertIcon(alert.type)}</div>
            <div className="flex-1 space-y-1">
              <div className="flex items-center justify-between gap-2">
                <h4 className="font-semibold text-sm">{alert.title}</h4>
                {getAlertBadge(alert.type)}
              </div>
              <p className="text-sm text-muted-foreground">{alert.message}</p>
              <p className="text-xs text-muted-foreground">{alert.date}</p>
            </div>
          </div>
        ))}
      </CardContent>
    </Card>
  );
}
