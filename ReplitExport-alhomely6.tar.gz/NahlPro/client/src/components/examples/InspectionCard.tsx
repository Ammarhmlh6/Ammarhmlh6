import InspectionCard from '../InspectionCard';

export default function InspectionCardExample() {
  return (
    <div className="grid gap-4 md:grid-cols-2 p-4">
      <InspectionCard
        date="منذ 3 أيام - 15 نوفمبر 2025"
        queenPresent={true}
        colonyStrength="قوية"
        broodPresent={true}
        honeyAmount="ممتلئة"
        actions="إضافة عسلة جديدة للتوسع"
      />
      <InspectionCard
        date="منذ أسبوع - 10 نوفمبر 2025"
        queenPresent={false}
        colonyStrength="ضعيفة"
        broodPresent={false}
        honeyAmount="قليلة"
        issues="الملكة غائبة، لا توجد حضنة"
        actions="إدخال ملكة جديدة، تغذية بعجينة السكر"
      />
    </div>
  );
}
