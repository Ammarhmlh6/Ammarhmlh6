import DashboardStats from '../DashboardStats';

export default function DashboardStatsExample() {
  return (
    <DashboardStats
      totalHives={24}
      activeHives={22}
      alerts={3}
      expectedProduction={450}
    />
  );
}
