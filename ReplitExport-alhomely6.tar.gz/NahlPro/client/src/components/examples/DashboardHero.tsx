import DashboardHero from '../DashboardHero';

export default function DashboardHeroExample() {
  return <DashboardHero />;
}
