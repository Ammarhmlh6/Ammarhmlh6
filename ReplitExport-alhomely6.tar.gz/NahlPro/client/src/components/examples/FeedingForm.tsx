import FeedingForm from '../FeedingForm';

export default function FeedingFormExample() {
  return (
    <div className="max-w-md mx-auto p-4">
      <FeedingForm />
    </div>
  );
}
