import AlertsList from '../AlertsList';

export default function AlertsListExample() {
  const mockAlerts = [
    {
      id: '1',
      type: 'urgent' as const,
      title: 'خلية 5 تحتاج فحص عاجل',
      message: 'لم يتم فحص الخلية منذ 20 يوماً',
      date: 'اليوم'
    },
    {
      id: '2',
      type: 'warning' as const,
      title: 'موعد تغذية الخلايا',
      message: '12 خلية تحتاج إلى تغذية هذا الأسبوع',
      date: 'منذ ساعتين'
    },
    {
      id: '3',
      type: 'info' as const,
      title: 'موسم القطاف قريب',
      message: 'من المتوقع أن يبدأ موسم القطاف خلال أسبوعين',
      date: 'منذ يوم'
    }
  ];

  return <AlertsList alerts={mockAlerts} />;
}
