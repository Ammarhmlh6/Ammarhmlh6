import HiveCard from '../HiveCard';

export default function HiveCardExample() {
  return (
    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3 p-4">
      <HiveCard
        id="1"
        name="خلية 1"
        type="أمريكي - لانجستروث"
        frames={10}
        queenStatus="موجودة"
        colonyStrength="قوية"
        lastInspection="منذ 3 أيام"
        onView={() => console.log('View hive clicked')}
        onEdit={() => console.log('Edit hive clicked')}
      />
      <HiveCard
        id="2"
        name="خلية 2"
        type="بلدي"
        frames={8}
        queenStatus="جديدة"
        colonyStrength="متوسطة"
        lastInspection="منذ أسبوع"
        hasIssues={true}
        onView={() => console.log('View hive clicked')}
        onEdit={() => console.log('Edit hive clicked')}
      />
      <HiveCard
        id="3"
        name="خلية 3"
        type="كيني"
        frames={12}
        queenStatus="غائبة"
        colonyStrength="ضعيفة"
        lastInspection="منذ أسبوعين"
        hasIssues={true}
        onView={() => console.log('View hive clicked')}
        onEdit={() => console.log('Edit hive clicked')}
      />
    </div>
  );
}
