import AddHiveDialog from '../AddHiveDialog';

export default function AddHiveDialogExample() {
  return <AddHiveDialog />;
}
