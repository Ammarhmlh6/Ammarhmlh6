import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Rabbit, Home, AlertTriangle, TrendingUp } from "lucide-react";

interface StatCardProps {
  title: string;
  value: string | number;
  icon: React.ReactNode;
  trend?: string;
}

function StatCard({ title, value, icon, trend }: StatCardProps) {
  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
        <CardTitle className="text-sm font-medium text-muted-foreground">
          {title}
        </CardTitle>
        <div className="h-9 w-9 rounded-md bg-primary/10 flex items-center justify-center text-primary">
          {icon}
        </div>
      </CardHeader>
      <CardContent>
        <div className="text-3xl font-bold">{value}</div>
        {trend && (
          <p className="text-xs text-muted-foreground mt-2">{trend}</p>
        )}
      </CardContent>
    </Card>
  );
}

interface DashboardStatsProps {
  totalHives: number;
  activeHives: number;
  alerts: number;
  expectedProduction: number;
}

export default function DashboardStats({
  totalHives,
  activeHives,
  alerts,
  expectedProduction,
}: DashboardStatsProps) {
  return (
    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
      <StatCard
        title="إجمالي الخلايا"
        value={totalHives}
        icon={<Home className="h-5 w-5" />}
        trend={`${activeHives} خلية نشطة`}
      />
      <StatCard
        title="الخلايا النشطة"
        value={activeHives}
        icon={<Rabbit className="h-5 w-5" />}
        trend={`${Math.round((activeHives / totalHives) * 100)}% من الإجمالي`}
      />
      <StatCard
        title="التنبيهات"
        value={alerts}
        icon={<AlertTriangle className="h-5 w-5" />}
        trend={alerts > 0 ? "تحتاج إلى متابعة" : "لا توجد تنبيهات"}
      />
      <StatCard
        title="الإنتاج المتوقع"
        value={`${expectedProduction} كجم`}
        icon={<TrendingUp className="h-5 w-5" />}
        trend="هذا الموسم"
      />
    </div>
  );
}
