import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Eye, Edit, AlertCircle } from "lucide-react";

interface HiveCardProps {
  id: string;
  name: string;
  type: string;
  frames: number;
  queenStatus: "موجودة" | "غائبة" | "جديدة";
  colonyStrength: "ضعيفة" | "متوسطة" | "قوية";
  lastInspection: string;
  hasIssues?: boolean;
  onView?: () => void;
  onEdit?: () => void;
}

export default function HiveCard({
  name,
  type,
  frames,
  queenStatus,
  colonyStrength,
  lastInspection,
  hasIssues = false,
  onView,
  onEdit,
}: HiveCardProps) {
  const getStrengthColor = () => {
    switch (colonyStrength) {
      case "قوية":
        return "bg-green-500/10 text-green-700 dark:text-green-400 border-green-500/20";
      case "متوسطة":
        return "bg-yellow-500/10 text-yellow-700 dark:text-yellow-400 border-yellow-500/20";
      case "ضعيفة":
        return "bg-red-500/10 text-red-700 dark:text-red-400 border-red-500/20";
    }
  };

  const getQueenColor = () => {
    switch (queenStatus) {
      case "موجودة":
        return "bg-blue-500/10 text-blue-700 dark:text-blue-400 border-blue-500/20";
      case "غائبة":
        return "bg-red-500/10 text-red-700 dark:text-red-400 border-red-500/20";
      case "جديدة":
        return "bg-green-500/10 text-green-700 dark:text-green-400 border-green-500/20";
    }
  };

  return (
    <Card className="hover-elevate transition-all">
      <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-3">
        <div className="flex-1">
          <CardTitle className="text-xl font-bold">{name}</CardTitle>
          <p className="text-sm text-muted-foreground mt-1">{type}</p>
        </div>
        {hasIssues && (
          <AlertCircle className="h-6 w-6 text-destructive" data-testid="icon-alert" />
        )}
      </CardHeader>
      <CardContent className="space-y-3">
        <div className="grid grid-cols-2 gap-3">
          <div>
            <p className="text-xs text-muted-foreground mb-1">عدد الأطارات</p>
            <p className="text-lg font-semibold">{frames}</p>
          </div>
          <div>
            <p className="text-xs text-muted-foreground mb-1">آخر فحص</p>
            <p className="text-lg font-semibold">{lastInspection}</p>
          </div>
        </div>
        <div className="flex gap-2 flex-wrap">
          <Badge variant="outline" className={getQueenColor()}>
            الملكة: {queenStatus}
          </Badge>
          <Badge variant="outline" className={getStrengthColor()}>
            {colonyStrength}
          </Badge>
        </div>
      </CardContent>
      <CardFooter className="flex gap-2 pt-3 border-t">
        <Button
          variant="outline"
          size="sm"
          className="flex-1"
          onClick={onView}
          data-testid="button-view-hive"
        >
          <Eye className="h-4 w-4 ml-2" />
          عرض التفاصيل
        </Button>
        <Button
          variant="outline"
          size="sm"
          className="flex-1"
          onClick={onEdit}
          data-testid="button-edit-hive"
        >
          <Edit className="h-4 w-4 ml-2" />
          تعديل
        </Button>
      </CardFooter>
    </Card>
  );
}
