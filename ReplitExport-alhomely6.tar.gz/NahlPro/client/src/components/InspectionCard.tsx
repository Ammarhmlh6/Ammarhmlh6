import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Calendar, CheckCircle, XCircle, AlertCircle } from "lucide-react";

interface InspectionCardProps {
  date: string;
  queenPresent: boolean;
  colonyStrength: "ضعيفة" | "متوسطة" | "قوية";
  broodPresent: boolean;
  honeyAmount: "فارغة" | "قليلة" | "متوسطة" | "ممتلئة";
  issues?: string;
  actions?: string;
}

export default function InspectionCard({
  date,
  queenPresent,
  colonyStrength,
  broodPresent,
  honeyAmount,
  issues,
  actions,
}: InspectionCardProps) {
  const getStrengthColor = () => {
    switch (colonyStrength) {
      case "قوية":
        return "bg-green-500/10 text-green-700 dark:text-green-400 border-green-500/20";
      case "متوسطة":
        return "bg-yellow-500/10 text-yellow-700 dark:text-yellow-400 border-yellow-500/20";
      case "ضعيفة":
        return "bg-red-500/10 text-red-700 dark:text-red-400 border-red-500/20";
    }
  };

  const getHoneyColor = () => {
    switch (honeyAmount) {
      case "ممتلئة":
        return "bg-primary/10 text-primary border-primary/20";
      case "متوسطة":
        return "bg-blue-500/10 text-blue-700 dark:text-blue-400 border-blue-500/20";
      case "قليلة":
        return "bg-yellow-500/10 text-yellow-700 dark:text-yellow-400 border-yellow-500/20";
      case "فارغة":
        return "bg-gray-500/10 text-gray-700 dark:text-gray-400 border-gray-500/20";
    }
  };

  return (
    <Card className="hover-elevate transition-all">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <Calendar className="h-4 w-4" />
            <span>{date}</span>
          </div>
          <Badge variant="outline" className={getStrengthColor()}>
            {colonyStrength}
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="space-y-3">
        <div className="grid grid-cols-2 gap-3 text-sm">
          <div className="flex items-center gap-2">
            {queenPresent ? (
              <CheckCircle className="h-4 w-4 text-green-600" />
            ) : (
              <XCircle className="h-4 w-4 text-red-600" />
            )}
            <span className="text-muted-foreground">الملكة: {queenPresent ? "موجودة" : "غائبة"}</span>
          </div>
          <div className="flex items-center gap-2">
            {broodPresent ? (
              <CheckCircle className="h-4 w-4 text-green-600" />
            ) : (
              <XCircle className="h-4 w-4 text-red-600" />
            )}
            <span className="text-muted-foreground">الحضنة: {broodPresent ? "موجودة" : "غائبة"}</span>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-sm text-muted-foreground">كمية العسل:</span>
          <Badge variant="outline" className={getHoneyColor()}>
            {honeyAmount}
          </Badge>
        </div>

        {issues && (
          <div className="flex items-start gap-2 p-2 rounded-md bg-destructive/10 border border-destructive/20">
            <AlertCircle className="h-4 w-4 text-destructive mt-0.5" />
            <div className="flex-1">
              <p className="text-sm font-medium text-destructive">مشاكل:</p>
              <p className="text-sm text-muted-foreground">{issues}</p>
            </div>
          </div>
        )}

        {actions && (
          <div className="p-2 rounded-md bg-muted/50 border">
            <p className="text-sm font-medium mb-1">الإجراءات المتخذة:</p>
            <p className="text-sm text-muted-foreground">{actions}</p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
