import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Coffee } from "lucide-react";

export default function FeedingForm() {
  const [feedingType, setFeedingType] = useState("");
  const [quantity, setQuantity] = useState("");
  const [notes, setNotes] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log("Recording feeding:", { feedingType, quantity, notes });
    setFeedingType("");
    setQuantity("");
    setNotes("");
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Coffee className="h-6 w-6 text-primary" />
          تسجيل تغذية جديدة
        </CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="feeding-type">نوع التغذية</Label>
            <Select value={feedingType} onValueChange={setFeedingType} required>
              <SelectTrigger id="feeding-type" data-testid="select-feeding-type">
                <SelectValue placeholder="اختر نوع التغذية" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="sugar-paste">عجينة السكر</SelectItem>
                <SelectItem value="protein-paste">عجينة البروتين</SelectItem>
                <SelectItem value="sugar-solution-1-1">محلول سكري 1:1</SelectItem>
                <SelectItem value="sugar-solution-2-1">محلول سكري 2:1</SelectItem>
                <SelectItem value="vitamins">محلول بالفيتامينات</SelectItem>
                <SelectItem value="pollen">بدائل حبوب اللقاح</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="quantity">الكمية (جرام أو مليلتر)</Label>
            <Input
              id="quantity"
              type="number"
              placeholder="500"
              value={quantity}
              onChange={(e) => setQuantity(e.target.value)}
              data-testid="input-quantity"
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="notes">ملاحظات (اختياري)</Label>
            <Textarea
              id="notes"
              placeholder="أي ملاحظات إضافية..."
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              data-testid="textarea-notes"
              rows={3}
            />
          </div>

          <Button type="submit" className="w-full" data-testid="button-submit-feeding">
            تسجيل التغذية
          </Button>
        </form>
      </CardContent>
    </Card>
  );
}
