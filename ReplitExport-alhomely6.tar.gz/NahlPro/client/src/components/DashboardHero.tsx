import heroImage from '@assets/generated_images/Modern_apiary_hero_image_c1eb6d99.png';

export default function DashboardHero() {
  return (
    <div className="relative h-[40vh] overflow-hidden rounded-lg">
      <img
        src={heroImage}
        alt="منحل حديث"
        className="w-full h-full object-cover"
      />
      <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/30 to-transparent" />
      <div className="absolute inset-0 flex flex-col items-center justify-center text-center text-white px-4">
        <h1 className="text-4xl md:text-5xl font-bold mb-3">
          مرحباً بك في تطبيق النحال المحترف
        </h1>
        <p className="text-lg md:text-xl text-white/90 max-w-2xl">
          إدارة شاملة لمناحلك وخلاياك مع تتبع دقيق للفحوصات والتغذية
        </p>
      </div>
    </div>
  );
}
