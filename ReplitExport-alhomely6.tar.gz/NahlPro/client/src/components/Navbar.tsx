import { useState } from "react";
import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { Menu, Home, Bug, ClipboardList, Coffee, Sun, Moon } from "lucide-react";

export default function Navbar() {
  const [location] = useLocation();
  const [open, setOpen] = useState(false);
  const [isDark, setIsDark] = useState(false);

  const toggleTheme = () => {
    setIsDark(!isDark);
    document.documentElement.classList.toggle("dark");
  };

  const navItems = [
    { path: "/", label: "لوحة المعلومات", icon: Home },
    { path: "/hives", label: "الخلايا", icon: Bug },
    { path: "/inspections", label: "الفحوصات", icon: ClipboardList },
    { path: "/feeding", label: "التغذية", icon: Coffee },
  ];

  const NavLink = ({ path, label, icon: Icon, mobile = false }: any) => {
    const isActive = location === path;
    return (
      <Link
        href={path}
        onClick={() => mobile && setOpen(false)}
        className={`flex items-center gap-3 px-4 py-2 rounded-md transition-colors ${
          isActive
            ? "bg-primary text-primary-foreground"
            : "hover-elevate text-foreground"
        }`}
        data-testid={`nav-link-${label}`}
      >
        <Icon className="h-5 w-5" />
        <span>{label}</span>
      </Link>
    );
  };

  return (
    <nav className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-16 items-center justify-between px-4">
        <div className="flex items-center gap-6">
          <Link href="/" className="flex items-center gap-2 font-bold text-xl" data-testid="link-logo">
            <Bug className="h-7 w-7 text-primary" />
            <span>النحال المحترف</span>
          </Link>

          <div className="hidden md:flex items-center gap-2">
            {navItems.map((item) => (
              <NavLink key={item.path} {...item} />
            ))}
          </div>
        </div>

        <div className="flex items-center gap-2">
          <Button
            variant="ghost"
            size="icon"
            onClick={toggleTheme}
            data-testid="button-theme-toggle"
          >
            {isDark ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
          </Button>

          <Sheet open={open} onOpenChange={setOpen}>
            <SheetTrigger asChild className="md:hidden">
              <Button variant="ghost" size="icon" data-testid="button-menu">
                <Menu className="h-6 w-6" />
              </Button>
            </SheetTrigger>
            <SheetContent side="right" className="w-64">
              <div className="flex flex-col gap-4 mt-8">
                {navItems.map((item) => (
                  <NavLink key={item.path} {...item} mobile />
                ))}
              </div>
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </nav>
  );
}
