import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { Plus } from "lucide-react";

export default function AddHiveDialog() {
  const [open, setOpen] = useState(false);
  const { toast } = useToast();
  const [formData, setFormData] = useState({
    name: "",
    type: "",
    frames: "",
    queenAge: "",
    colonyStrength: "",
  });

  const createHiveMutation = useMutation({
    mutationFn: async (data: any) => {
      const response = await apiRequest('POST', '/api/hives', data);
      return await response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/hives'] });
      queryClient.invalidateQueries({ queryKey: ['/api/dashboard/stats'] });
      toast({
        title: "تم إضافة الخلية بنجاح",
        description: "تم إضافة الخلية الجديدة إلى المنحل",
      });
      setOpen(false);
      setFormData({ name: "", type: "", frames: "", queenAge: "", colonyStrength: "" });
    },
    onError: (error: any) => {
      toast({
        variant: "destructive",
        title: "خطأ في إضافة الخلية",
        description: error.message || "حدث خطأ أثناء إضافة الخلية",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    createHiveMutation.mutate({
      name: formData.name,
      type: formData.type,
      frames: parseInt(formData.frames),
      queenAge: formData.queenAge ? parseInt(formData.queenAge) : null,
      colonyStrength: formData.colonyStrength,
      apiaryId: null,
      queenSource: null,
      colonySource: null,
      installationDate: new Date(),
      isActive: true,
      notes: null,
    });
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button data-testid="button-add-hive">
          <Plus className="h-5 w-5 ml-2" />
          إضافة خلية جديدة
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle className="text-2xl">إضافة خلية جديدة</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4 mt-4">
          <div className="space-y-2">
            <Label htmlFor="name">اسم الخلية</Label>
            <Input
              id="name"
              placeholder="مثال: خلية 1"
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              data-testid="input-hive-name"
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="type">نوع الخلية</Label>
            <Select
              value={formData.type}
              onValueChange={(value) => setFormData({ ...formData, type: value })}
              required
            >
              <SelectTrigger id="type" data-testid="select-hive-type">
                <SelectValue placeholder="اختر نوع الخلية" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="american">أمريكي - لانجستروث</SelectItem>
                <SelectItem value="local">بلدي</SelectItem>
                <SelectItem value="kenyan">كيني</SelectItem>
                <SelectItem value="warre">وارية</SelectItem>
                <SelectItem value="dadant">دادان</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="frames">عدد الأطارات</Label>
              <Input
                id="frames"
                type="number"
                placeholder="10"
                value={formData.frames}
                onChange={(e) => setFormData({ ...formData, frames: e.target.value })}
                data-testid="input-frames"
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="queenAge">عمر الملكة (أشهر)</Label>
              <Input
                id="queenAge"
                type="number"
                placeholder="6"
                value={formData.queenAge}
                onChange={(e) => setFormData({ ...formData, queenAge: e.target.value })}
                data-testid="input-queen-age"
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="strength">قوة الطائفة</Label>
            <Select
              value={formData.colonyStrength}
              onValueChange={(value) => setFormData({ ...formData, colonyStrength: value })}
              required
            >
              <SelectTrigger id="strength" data-testid="select-colony-strength">
                <SelectValue placeholder="اختر قوة الطائفة" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="weak">ضعيفة</SelectItem>
                <SelectItem value="medium">متوسطة</SelectItem>
                <SelectItem value="strong">قوية</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="flex gap-3 pt-4">
            <Button 
              type="submit" 
              className="flex-1" 
              data-testid="button-submit-hive"
              disabled={createHiveMutation.isPending}
            >
              {createHiveMutation.isPending ? "جار الإضافة..." : "إضافة الخلية"}
            </Button>
            <Button
              type="button"
              variant="outline"
              onClick={() => setOpen(false)}
              data-testid="button-cancel"
              disabled={createHiveMutation.isPending}
            >
              إلغاء
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
