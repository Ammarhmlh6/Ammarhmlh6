import { pgTable, text, serial, integer, timestamp, boolean, real, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// المناحل (Apiaries)
export const apiaries = pgTable("apiaries", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  location: text("location").notNull(),
  latitude: real("latitude"),
  longitude: real("longitude"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  notes: text("notes"),
});

export const insertApiarySchema = createInsertSchema(apiaries).omit({ id: true, createdAt: true });
export type InsertApiary = z.infer<typeof insertApiarySchema>;
export type Apiary = typeof apiaries.$inferSelect;

// الخلايا (Hives)
export const hives = pgTable("hives", {
  id: serial("id").primaryKey(),
  apiaryId: integer("apiary_id").references(() => apiaries.id),
  name: text("name").notNull(),
  type: text("type").notNull(), // بلدي، أمريكي، كيني، وارية، دادان
  frames: integer("frames").notNull(),
  queenAge: integer("queen_age"), // عمر الملكة بالأشهر
  queenSource: text("queen_source"), // مصدر الملكة
  colonyStrength: text("colony_strength").notNull(), // ضعيفة، متوسطة، قوية
  colonySource: text("colony_source"), // مصدر الطائفة
  installationDate: timestamp("installation_date"),
  isActive: boolean("is_active").default(true).notNull(),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertHiveSchema = createInsertSchema(hives).omit({ id: true, createdAt: true });
export type InsertHive = z.infer<typeof insertHiveSchema>;
export type Hive = typeof hives.$inferSelect;

// العسلات (Supers) - إدارة ديناميكية
export const supers = pgTable("supers", {
  id: serial("id").primaryKey(),
  hiveId: integer("hive_id").references(() => hives.id).notNull(),
  type: text("type").notNull(), // عميقة، ضحلة
  frames: integer("frames").notNull(),
  position: integer("position").notNull(), // موقع العسلة (الطابق)
  status: text("status").notNull(), // فارغة، جزئياً، ممتلئة
  addedDate: timestamp("added_date").defaultNow().notNull(),
  removedDate: timestamp("removed_date"),
  removalReason: text("removal_reason"),
  honeyHarvested: real("honey_harvested"), // كمية العسل عند الإزالة (كجم)
  isActive: boolean("is_active").default(true).notNull(),
  notes: text("notes"),
});

export const insertSuperSchema = createInsertSchema(supers).omit({ id: true, addedDate: true });
export type InsertSuper = z.infer<typeof insertSuperSchema>;
export type Super = typeof supers.$inferSelect;

// الفحوصات (Inspections)
export const inspections = pgTable("inspections", {
  id: serial("id").primaryKey(),
  hiveId: integer("hive_id").references(() => hives.id).notNull(),
  inspectionDate: timestamp("inspection_date").defaultNow().notNull(),
  queenPresent: boolean("queen_present").notNull(),
  queenSeen: boolean("queen_seen").default(false).notNull(),
  eggsPresent: boolean("eggs_present").notNull(),
  broodPresent: boolean("brood_present").notNull(),
  broodPattern: text("brood_pattern"), // جيد، متوسط، سيء
  colonyStrength: text("colony_strength").notNull(),
  temper: text("temper"), // هادئة، متوسطة، عدوانية
  honeyAmount: text("honey_amount").notNull(), // فارغة، قليلة، متوسطة، ممتلئة
  pollenAmount: text("pollen_amount"), // فارغة، قليلة، متوسطة، ممتلئة
  frameDetails: jsonb("frame_details"), // تفاصيل كل إطار
  diseases: text("diseases").array(),
  pests: text("pests").array(),
  issues: text("issues"),
  actionsTaken: text("actions_taken"),
  weather: text("weather"),
  temperature: real("temperature"),
  notes: text("notes"),
});

export const insertInspectionSchema = createInsertSchema(inspections).omit({ id: true });
export type InsertInspection = z.infer<typeof insertInspectionSchema>;
export type Inspection = typeof inspections.$inferSelect;

// التغذية (Feeding)
export const feedings = pgTable("feedings", {
  id: serial("id").primaryKey(),
  hiveId: integer("hive_id").references(() => hives.id),
  feedingDate: timestamp("feeding_date").defaultNow().notNull(),
  feedingType: text("feeding_type").notNull(), // عجينة السكر، محلول سكري، بروتين، إلخ
  quantity: real("quantity").notNull(), // جرام أو مليلتر
  reason: text("reason"), // ضعف، شتاء، تقوية، علاج
  recipe: text("recipe"), // الوصفة المستخدمة
  cost: real("cost"),
  weather: text("weather"),
  notes: text("notes"),
});

export const insertFeedingSchema = createInsertSchema(feedings).omit({ id: true });
export type InsertFeeding = z.infer<typeof insertFeedingSchema>;
export type Feeding = typeof feedings.$inferSelect;

// الغذاء الملكي (Royal Jelly Production)
export const royalJellyProduction = pgTable("royal_jelly_production", {
  id: serial("id").primaryKey(),
  hiveId: integer("hive_id").references(() => hives.id).notNull(),
  cycleStartDate: timestamp("cycle_start_date").notNull(),
  graftingDate: timestamp("grafting_date").notNull(),
  harvestDate: timestamp("harvest_date"),
  cupsGrafted: integer("cups_grafted").notNull(),
  cupsAccepted: integer("cups_accepted"),
  cupsHarvested: integer("cups_harvested"),
  quantityProduced: real("quantity_produced"), // جرام
  quality: text("quality"), // ممتاز، جيد، متوسط
  storageMethod: text("storage_method"),
  notes: text("notes"),
});

export const insertRoyalJellyProductionSchema = createInsertSchema(royalJellyProduction).omit({ id: true });
export type InsertRoyalJellyProduction = z.infer<typeof insertRoyalJellyProductionSchema>;
export type RoyalJellyProduction = typeof royalJellyProduction.$inferSelect;

// حبوب اللقاح (Pollen Collection)
export const pollenCollection = pgTable("pollen_collection", {
  id: serial("id").primaryKey(),
  hiveId: integer("hive_id").references(() => hives.id).notNull(),
  collectionDate: timestamp("collection_date").defaultNow().notNull(),
  trapInstallDate: timestamp("trap_install_date"),
  trapType: text("trap_type"),
  quantityCollected: real("quantity_collected").notNull(), // جرام
  colors: text("colors").array(), // ألوان حبوب اللقاح
  source: text("source"), // نوع النباتات
  quality: text("quality"),
  moistureContent: real("moisture_content"),
  storageMethod: text("storage_method"),
  notes: text("notes"),
});

export const insertPollenCollectionSchema = createInsertSchema(pollenCollection).omit({ id: true });
export type InsertPollenCollection = z.infer<typeof insertPollenCollectionSchema>;
export type PollenCollection = typeof pollenCollection.$inferSelect;

// حصاد العسل (Honey Harvest)
export const honeyHarvest = pgTable("honey_harvest", {
  id: serial("id").primaryKey(),
  hiveId: integer("hive_id").references(() => hives.id).notNull(),
  harvestDate: timestamp("harvest_date").defaultNow().notNull(),
  framesHarvested: integer("frames_harvested").notNull(),
  honeyType: text("honey_type"), // زهور، سدر، حمضيات، إلخ
  quantityExtracted: real("quantity_extracted").notNull(), // كجم
  moistureContent: real("moisture_content"),
  extractionMethod: text("extraction_method"), // يدوي، آلي
  bottled: boolean("bottled").default(false),
  bottleSize: text("bottle_size"),
  bottleCount: integer("bottle_count"),
  weather: text("weather"),
  notes: text("notes"),
});

export const insertHoneyHarvestSchema = createInsertSchema(honeyHarvest).omit({ id: true });
export type InsertHoneyHarvest = z.infer<typeof insertHoneyHarvestSchema>;
export type HoneyHarvest = typeof honeyHarvest.$inferSelect;

// تربية الملكات (Queen Rearing)
export const queenRearing = pgTable("queen_rearing", {
  id: serial("id").primaryKey(),
  motherHiveId: integer("mother_hive_id").references(() => hives.id).notNull(),
  breederHiveId: integer("breeder_hive_id").references(() => hives.id),
  graftingDate: timestamp("grafting_date").notNull(),
  cupsGrafted: integer("cups_grafted").notNull(),
  cupsAccepted: integer("cups_accepted"),
  emergenceDate: timestamp("emergence_date"),
  queensProduced: integer("queens_produced"),
  matingMethod: text("mating_method"), // طبيعي، صناعي
  matingDate: timestamp("mating_date"),
  layingStartDate: timestamp("laying_start_date"),
  layingRate: text("laying_rate"),
  broodQuality: text("brood_quality"),
  strain: text("strain"), // السلالة
  parentage: text("parentage"), // النسب
  notes: text("notes"),
});

export const insertQueenRearingSchema = createInsertSchema(queenRearing).omit({ id: true });
export type InsertQueenRearing = z.infer<typeof insertQueenRearingSchema>;
export type QueenRearing = typeof queenRearing.$inferSelect;

// المخزون (Inventory)
export const inventory = pgTable("inventory", {
  id: serial("id").primaryKey(),
  productType: text("product_type").notNull(), // عسل، غذاء ملكي، حبوب لقاح، ملكة
  quantity: real("quantity").notNull(),
  unit: text("unit").notNull(), // كجم، جرام، قطعة
  productionDate: timestamp("production_date"),
  expiryDate: timestamp("expiry_date"),
  quality: text("quality"),
  storageLocation: text("storage_location"),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertInventorySchema = createInsertSchema(inventory).omit({ id: true, createdAt: true });
export type InsertInventory = z.infer<typeof insertInventorySchema>;
export type Inventory = typeof inventory.$inferSelect;

// المبيعات (Sales)
export const sales = pgTable("sales", {
  id: serial("id").primaryKey(),
  saleDate: timestamp("sale_date").defaultNow().notNull(),
  productType: text("product_type").notNull(),
  quantity: real("quantity").notNull(),
  unit: text("unit").notNull(),
  pricePerUnit: real("price_per_unit").notNull(),
  totalAmount: real("total_amount").notNull(),
  customerName: text("customer_name"),
  customerPhone: text("customer_phone"),
  paymentMethod: text("payment_method"),
  paymentStatus: text("payment_status").default('paid').notNull(),
  notes: text("notes"),
});

export const insertSaleSchema = createInsertSchema(sales).omit({ id: true });
export type InsertSale = z.infer<typeof insertSaleSchema>;
export type Sale = typeof sales.$inferSelect;

// التنبيهات (Alerts)
export const alerts = pgTable("alerts", {
  id: serial("id").primaryKey(),
  hiveId: integer("hive_id").references(() => hives.id),
  alertType: text("alert_type").notNull(), // urgent, warning, info
  title: text("title").notNull(),
  message: text("message").notNull(),
  isRead: boolean("is_read").default(false).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertAlertSchema = createInsertSchema(alerts).omit({ id: true, createdAt: true });
export type InsertAlert = z.infer<typeof insertAlertSchema>;
export type Alert = typeof alerts.$inferSelect;
