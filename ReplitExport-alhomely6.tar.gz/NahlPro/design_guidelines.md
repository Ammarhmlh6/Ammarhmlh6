# تصميم تطبيق النحال المحترف - Design Guidelines

## Design Approach

**Selected System**: Material Design adapted for productivity and data management
**Rationale**: Information-dense agricultural management application requiring clarity, efficiency, and mobile-first design with full RTL Arabic support.

**Core Principles**:
- Clarity over decoration: Every element serves a functional purpose
- Mobile-first workflow: Beekeepers use this in the field
- Data hierarchy: Critical information always visible
- RTL-optimized: Native Arabic reading patterns

---

## Typography System

### Font Families
- **Primary**: 'Cairo' or 'Tajawal' (Google Fonts) - excellent Arabic readability
- **Numerical Data**: 'IBM Plex Sans Arabic' - clear numbers and statistics
- **English Fallback**: 'Inter' for mixed content

### Hierarchy
- **Page Headers**: text-3xl font-bold (للعناوين الرئيسية)
- **Section Headers**: text-xl font-semibold (عناوين الأقسام)
- **Card Titles**: text-lg font-medium (عناوين البطاقات)
- **Body Text**: text-base font-normal (النص الأساسي)
- **Labels**: text-sm font-medium (التسميات)
- **Metadata**: text-xs (البيانات الثانوية)

---

## Layout System

### Spacing Primitives
**Standard Units**: 2, 4, 6, 8, 12, 16 (tailwind units)
- Component padding: p-4, p-6
- Section spacing: py-8, py-12
- Card gaps: gap-4, gap-6
- Form fields: space-y-4

### Container Strategy
- **Mobile**: Full width with px-4 padding
- **Tablet**: max-w-3xl mx-auto
- **Desktop**: max-w-7xl mx-auto with grid layouts
- **Forms**: max-w-2xl for optimal readability

### Grid Patterns
- **Dashboard Stats**: grid-cols-1 md:grid-cols-2 lg:grid-cols-4
- **Hive Cards**: grid-cols-1 md:grid-cols-2 lg:grid-cols-3
- **Form Layouts**: Single column on mobile, 2-column on desktop (grid-cols-1 lg:grid-cols-2)

---

## Component Library

### Navigation
**Top App Bar** (Material Design):
- Fixed header with app title and user menu
- Mobile: Hamburger menu with drawer
- Desktop: Horizontal navigation
- Includes: المناحل، الخلايا، الفحوصات، التنبيهات، التقارير

### Cards System
**Hive Information Cards**:
- Elevated cards with shadow-md
- Header with hive number/name (prominent)
- Icon indicators for status (queen present, disease alerts)
- Quick stats grid (frames count, last inspection date)
- Action buttons at bottom

**Inspection Cards**:
- Timeline-style layout showing history
- Date badges (absolute positioned)
- Collapsible details
- Status indicators (strong/medium/weak colony)

### Forms
**Multi-Step Forms** for adding hives:
- Progress indicator at top
- Step 1: Basic info (type, frames count)
- Step 2: Colony status (queen, age)
- Step 3: Frame details
- Navigation: Previous/Next buttons with validation

**Input Fields**:
- Floating labels (Material style)
- Helper text below inputs
- Error states with clear messaging
- Number spinners for counts
- Date pickers for inspections
- Dropdown selects for predefined options (hive types)

### Dashboard
**Statistics Overview**:
- KPI cards in grid (total hives, active hives, upcoming tasks)
- Large numbers with context labels
- Icon + number + label pattern

**Alerts Section**:
- List view with priority indicators
- Grouped by urgency (عاجل، قريباً، معلومات)
- Swipe-to-dismiss on mobile

### Data Display
**Tables** (for inspection history):
- Responsive: Cards on mobile, table on desktop
- Sortable columns
- Filter chips at top
- Pagination at bottom

**Status Indicators**:
- Badge components for states (healthy, warning, critical)
- Icon + text combinations
- Consistent positioning (top-right of cards)

---

## Mobile Optimization

### Touch Targets
- Minimum button height: h-12 (48px)
- Adequate spacing between interactive elements: gap-3
- Bottom sheet patterns for secondary actions
- Floating Action Button (FAB) for "إضافة خلية جديدة"

### Gestures
- Pull-to-refresh on lists
- Swipe actions on cards (edit/delete)
- Bottom navigation bar with 4-5 key sections

---

## RTL Considerations

- All layouts mirror for RTL (flex-row-reverse where needed)
- Icons positioned on right side of text
- Forms align right
- Charts and graphs maintain RTL data flow
- Navigation drawer slides from right

---

## Images

**Dashboard Header Section**:
- Hero image (not full-screen): Modern apiary scene (height: 40vh max)
- Purpose: Establish context and warmth
- Overlay: Semi-transparent gradient for text readability

**Empty States**:
- Illustrated icons for "لا توجد خلايا" (no hives yet)
- Friendly, minimal illustrations

**Icons**: Use Material Icons CDN for consistency (beehive, calendar, warning, check-circle, etc.)

---

## Interaction Patterns

**No animations** except:
- Simple fade transitions for modal/drawer open (200ms)
- Loading spinners for async operations
- Toast notifications for confirmations (slide-in from top)

---

## Accessibility (Arabic Context)

- High contrast text-to-background ratios
- Clear focus indicators (ring-2 ring-offset-2)
- Keyboard navigation support
- Screen reader labels in Arabic
- Form validation messages in clear Arabic