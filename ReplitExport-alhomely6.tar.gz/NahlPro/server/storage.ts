import { db } from "./db";
import { 
  type Apiary, type InsertApiary, apiaries,
  type Hive, type InsertHive, hives,
  type Super, type InsertSuper, supers,
  type Inspection, type InsertInspection, inspections,
  type Feeding, type InsertFeeding, feedings,
  type RoyalJellyProduction, type InsertRoyalJellyProduction, royalJellyProduction,
  type PollenCollection, type InsertPollenCollection, pollenCollection,
  type HoneyHarvest, type InsertHoneyHarvest, honeyHarvest,
  type QueenRearing, type InsertQueenRearing, queenRearing,
  type Inventory, type InsertInventory, inventory,
  type Sale, type InsertSale, sales,
  type Alert, type InsertAlert, alerts,
} from "@shared/schema";
import { eq, desc, and, gte, lte } from "drizzle-orm";

export interface IStorage {
  // Apiaries
  getApiaries(): Promise<Apiary[]>;
  getApiary(id: number): Promise<Apiary | undefined>;
  createApiary(apiary: InsertApiary): Promise<Apiary>;
  updateApiary(id: number, apiary: Partial<InsertApiary>): Promise<Apiary | undefined>;
  deleteApiary(id: number): Promise<boolean>;

  // Hives
  getHives(apiaryId?: number): Promise<Hive[]>;
  getHive(id: number): Promise<Hive | undefined>;
  createHive(hive: InsertHive): Promise<Hive>;
  updateHive(id: number, hive: Partial<InsertHive>): Promise<Hive | undefined>;
  deleteHive(id: number): Promise<boolean>;

  // Supers
  getSupers(hiveId: number): Promise<Super[]>;
  getSuper(id: number): Promise<Super | undefined>;
  createSuper(superData: InsertSuper): Promise<Super>;
  updateSuper(id: number, superData: Partial<InsertSuper>): Promise<Super | undefined>;
  removeSuper(id: number, removalReason: string, honeyHarvested?: number): Promise<Super | undefined>;

  // Inspections
  getInspections(hiveId?: number): Promise<Inspection[]>;
  getInspection(id: number): Promise<Inspection | undefined>;
  createInspection(inspection: InsertInspection): Promise<Inspection>;
  updateInspection(id: number, inspection: Partial<InsertInspection>): Promise<Inspection | undefined>;

  // Feeding
  getFeedings(hiveId?: number): Promise<Feeding[]>;
  getFeeding(id: number): Promise<Feeding | undefined>;
  createFeeding(feeding: InsertFeeding): Promise<Feeding>;

  // Royal Jelly
  getRoyalJellyProductions(hiveId?: number): Promise<RoyalJellyProduction[]>;
  getRoyalJellyProduction(id: number): Promise<RoyalJellyProduction | undefined>;
  createRoyalJellyProduction(production: InsertRoyalJellyProduction): Promise<RoyalJellyProduction>;
  updateRoyalJellyProduction(id: number, production: Partial<InsertRoyalJellyProduction>): Promise<RoyalJellyProduction | undefined>;

  // Pollen
  getPollenCollections(hiveId?: number): Promise<PollenCollection[]>;
  getPollenCollection(id: number): Promise<PollenCollection | undefined>;
  createPollenCollection(collection: InsertPollenCollection): Promise<PollenCollection>;

  // Honey Harvest
  getHoneyHarvests(hiveId?: number): Promise<HoneyHarvest[]>;
  getHoneyHarvest(id: number): Promise<HoneyHarvest | undefined>;
  createHoneyHarvest(harvest: InsertHoneyHarvest): Promise<HoneyHarvest>;

  // Queen Rearing
  getQueenRearings(): Promise<QueenRearing[]>;
  getQueenRearing(id: number): Promise<QueenRearing | undefined>;
  createQueenRearing(rearing: InsertQueenRearing): Promise<QueenRearing>;
  updateQueenRearing(id: number, rearing: Partial<InsertQueenRearing>): Promise<QueenRearing | undefined>;

  // Inventory
  getInventory(): Promise<Inventory[]>;
  createInventoryItem(item: InsertInventory): Promise<Inventory>;
  updateInventoryItem(id: number, item: Partial<InsertInventory>): Promise<Inventory | undefined>;

  // Sales
  getSales(): Promise<Sale[]>;
  getSale(id: number): Promise<Sale | undefined>;
  createSale(sale: InsertSale): Promise<Sale>;

  // Alerts
  getAlerts(unreadOnly?: boolean): Promise<Alert[]>;
  createAlert(alert: InsertAlert): Promise<Alert>;
  markAlertAsRead(id: number): Promise<Alert | undefined>;
}

export class DbStorage implements IStorage {
  // Apiaries
  async getApiaries(): Promise<Apiary[]> {
    return await db.select().from(apiaries).orderBy(desc(apiaries.createdAt));
  }

  async getApiary(id: number): Promise<Apiary | undefined> {
    const result = await db.select().from(apiaries).where(eq(apiaries.id, id));
    return result[0];
  }

  async createApiary(apiary: InsertApiary): Promise<Apiary> {
    const result = await db.insert(apiaries).values(apiary).returning();
    return result[0];
  }

  async updateApiary(id: number, apiary: Partial<InsertApiary>): Promise<Apiary | undefined> {
    const result = await db.update(apiaries).set(apiary).where(eq(apiaries.id, id)).returning();
    return result[0];
  }

  async deleteApiary(id: number): Promise<boolean> {
    const result = await db.delete(apiaries).where(eq(apiaries.id, id));
    return result.rowCount > 0;
  }

  // Hives
  async getHives(apiaryId?: number): Promise<Hive[]> {
    if (apiaryId) {
      return await db.select().from(hives).where(eq(hives.apiaryId, apiaryId)).orderBy(desc(hives.createdAt));
    }
    return await db.select().from(hives).orderBy(desc(hives.createdAt));
  }

  async getHive(id: number): Promise<Hive | undefined> {
    const result = await db.select().from(hives).where(eq(hives.id, id));
    return result[0];
  }

  async createHive(hive: InsertHive): Promise<Hive> {
    const result = await db.insert(hives).values(hive).returning();
    return result[0];
  }

  async updateHive(id: number, hive: Partial<InsertHive>): Promise<Hive | undefined> {
    const result = await db.update(hives).set(hive).where(eq(hives.id, id)).returning();
    return result[0];
  }

  async deleteHive(id: number): Promise<boolean> {
    const result = await db.delete(hives).where(eq(hives.id, id));
    return result.rowCount > 0;
  }

  // Supers
  async getSupers(hiveId: number): Promise<Super[]> {
    return await db.select().from(supers)
      .where(and(eq(supers.hiveId, hiveId), eq(supers.isActive, true)))
      .orderBy(supers.position);
  }

  async getSuper(id: number): Promise<Super | undefined> {
    const result = await db.select().from(supers).where(eq(supers.id, id));
    return result[0];
  }

  async createSuper(superData: InsertSuper): Promise<Super> {
    const result = await db.insert(supers).values(superData).returning();
    return result[0];
  }

  async updateSuper(id: number, superData: Partial<InsertSuper>): Promise<Super | undefined> {
    const result = await db.update(supers).set(superData).where(eq(supers.id, id)).returning();
    return result[0];
  }

  async removeSuper(id: number, removalReason: string, honeyHarvested?: number): Promise<Super | undefined> {
    const result = await db.update(supers).set({
      isActive: false,
      removedDate: new Date(),
      removalReason,
      honeyHarvested,
    }).where(eq(supers.id, id)).returning();
    return result[0];
  }

  // Inspections
  async getInspections(hiveId?: number): Promise<Inspection[]> {
    if (hiveId) {
      return await db.select().from(inspections).where(eq(inspections.hiveId, hiveId)).orderBy(desc(inspections.inspectionDate));
    }
    return await db.select().from(inspections).orderBy(desc(inspections.inspectionDate));
  }

  async getInspection(id: number): Promise<Inspection | undefined> {
    const result = await db.select().from(inspections).where(eq(inspections.id, id));
    return result[0];
  }

  async createInspection(inspection: InsertInspection): Promise<Inspection> {
    const result = await db.insert(inspections).values(inspection).returning();
    return result[0];
  }

  async updateInspection(id: number, inspection: Partial<InsertInspection>): Promise<Inspection | undefined> {
    const result = await db.update(inspections).set(inspection).where(eq(inspections.id, id)).returning();
    return result[0];
  }

  // Feeding
  async getFeedings(hiveId?: number): Promise<Feeding[]> {
    if (hiveId) {
      return await db.select().from(feedings).where(eq(feedings.hiveId, hiveId)).orderBy(desc(feedings.feedingDate));
    }
    return await db.select().from(feedings).orderBy(desc(feedings.feedingDate));
  }

  async getFeeding(id: number): Promise<Feeding | undefined> {
    const result = await db.select().from(feedings).where(eq(feedings.id, id));
    return result[0];
  }

  async createFeeding(feeding: InsertFeeding): Promise<Feeding> {
    const result = await db.insert(feedings).values(feeding).returning();
    return result[0];
  }

  // Royal Jelly
  async getRoyalJellyProductions(hiveId?: number): Promise<RoyalJellyProduction[]> {
    if (hiveId) {
      return await db.select().from(royalJellyProduction).where(eq(royalJellyProduction.hiveId, hiveId)).orderBy(desc(royalJellyProduction.cycleStartDate));
    }
    return await db.select().from(royalJellyProduction).orderBy(desc(royalJellyProduction.cycleStartDate));
  }

  async getRoyalJellyProduction(id: number): Promise<RoyalJellyProduction | undefined> {
    const result = await db.select().from(royalJellyProduction).where(eq(royalJellyProduction.id, id));
    return result[0];
  }

  async createRoyalJellyProduction(production: InsertRoyalJellyProduction): Promise<RoyalJellyProduction> {
    const result = await db.insert(royalJellyProduction).values(production).returning();
    return result[0];
  }

  async updateRoyalJellyProduction(id: number, production: Partial<InsertRoyalJellyProduction>): Promise<RoyalJellyProduction | undefined> {
    const result = await db.update(royalJellyProduction).set(production).where(eq(royalJellyProduction.id, id)).returning();
    return result[0];
  }

  // Pollen
  async getPollenCollections(hiveId?: number): Promise<PollenCollection[]> {
    if (hiveId) {
      return await db.select().from(pollenCollection).where(eq(pollenCollection.hiveId, hiveId)).orderBy(desc(pollenCollection.collectionDate));
    }
    return await db.select().from(pollenCollection).orderBy(desc(pollenCollection.collectionDate));
  }

  async getPollenCollection(id: number): Promise<PollenCollection | undefined> {
    const result = await db.select().from(pollenCollection).where(eq(pollenCollection.id, id));
    return result[0];
  }

  async createPollenCollection(collection: InsertPollenCollection): Promise<PollenCollection> {
    const result = await db.insert(pollenCollection).values(collection).returning();
    return result[0];
  }

  // Honey Harvest
  async getHoneyHarvests(hiveId?: number): Promise<HoneyHarvest[]> {
    if (hiveId) {
      return await db.select().from(honeyHarvest).where(eq(honeyHarvest.hiveId, hiveId)).orderBy(desc(honeyHarvest.harvestDate));
    }
    return await db.select().from(honeyHarvest).orderBy(desc(honeyHarvest.harvestDate));
  }

  async getHoneyHarvest(id: number): Promise<HoneyHarvest | undefined> {
    const result = await db.select().from(honeyHarvest).where(eq(honeyHarvest.id, id));
    return result[0];
  }

  async createHoneyHarvest(harvest: InsertHoneyHarvest): Promise<HoneyHarvest> {
    const result = await db.insert(honeyHarvest).values(harvest).returning();
    return result[0];
  }

  // Queen Rearing
  async getQueenRearings(): Promise<QueenRearing[]> {
    return await db.select().from(queenRearing).orderBy(desc(queenRearing.graftingDate));
  }

  async getQueenRearing(id: number): Promise<QueenRearing | undefined> {
    const result = await db.select().from(queenRearing).where(eq(queenRearing.id, id));
    return result[0];
  }

  async createQueenRearing(rearing: InsertQueenRearing): Promise<QueenRearing> {
    const result = await db.insert(queenRearing).values(rearing).returning();
    return result[0];
  }

  async updateQueenRearing(id: number, rearing: Partial<InsertQueenRearing>): Promise<QueenRearing | undefined> {
    const result = await db.update(queenRearing).set(rearing).where(eq(queenRearing.id, id)).returning();
    return result[0];
  }

  // Inventory
  async getInventory(): Promise<Inventory[]> {
    return await db.select().from(inventory).orderBy(desc(inventory.createdAt));
  }

  async createInventoryItem(item: InsertInventory): Promise<Inventory> {
    const result = await db.insert(inventory).values(item).returning();
    return result[0];
  }

  async updateInventoryItem(id: number, item: Partial<InsertInventory>): Promise<Inventory | undefined> {
    const result = await db.update(inventory).set(item).where(eq(inventory.id, id)).returning();
    return result[0];
  }

  // Sales
  async getSales(): Promise<Sale[]> {
    return await db.select().from(sales).orderBy(desc(sales.saleDate));
  }

  async getSale(id: number): Promise<Sale | undefined> {
    const result = await db.select().from(sales).where(eq(sales.id, id));
    return result[0];
  }

  async createSale(sale: InsertSale): Promise<Sale> {
    const result = await db.insert(sales).values(sale).returning();
    return result[0];
  }

  // Alerts
  async getAlerts(unreadOnly?: boolean): Promise<Alert[]> {
    if (unreadOnly) {
      return await db.select().from(alerts).where(eq(alerts.isRead, false)).orderBy(desc(alerts.createdAt));
    }
    return await db.select().from(alerts).orderBy(desc(alerts.createdAt));
  }

  async createAlert(alert: InsertAlert): Promise<Alert> {
    const result = await db.insert(alerts).values(alert).returning();
    return result[0];
  }

  async markAlertAsRead(id: number): Promise<Alert | undefined> {
    const result = await db.update(alerts).set({ isRead: true }).where(eq(alerts.id, id)).returning();
    return result[0];
  }
}

export const storage = new DbStorage();
