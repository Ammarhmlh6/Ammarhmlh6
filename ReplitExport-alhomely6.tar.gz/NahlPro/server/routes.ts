import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { 
  insertApiarySchema, insertHiveSchema, insertSuperSchema,
  insertInspectionSchema, insertFeedingSchema,
  insertRoyalJellyProductionSchema, insertPollenCollectionSchema,
  insertHoneyHarvestSchema, insertQueenRearingSchema,
  insertInventorySchema, insertSaleSchema, insertAlertSchema
} from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // ========== Apiaries ==========
  app.get("/api/apiaries", async (_req, res) => {
    try {
      const apiaries = await storage.getApiaries();
      res.json(apiaries);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.get("/api/apiaries/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const apiary = await storage.getApiary(id);
      if (!apiary) {
        return res.status(404).json({ error: "Apiary not found" });
      }
      res.json(apiary);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.post("/api/apiaries", async (req, res) => {
    try {
      const data = insertApiarySchema.parse(req.body);
      const apiary = await storage.createApiary(data);
      res.status(201).json(apiary);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  app.patch("/api/apiaries/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const apiary = await storage.updateApiary(id, req.body);
      if (!apiary) {
        return res.status(404).json({ error: "Apiary not found" });
      }
      res.json(apiary);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  app.delete("/api/apiaries/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const success = await storage.deleteApiary(id);
      if (!success) {
        return res.status(404).json({ error: "Apiary not found" });
      }
      res.status(204).send();
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // ========== Hives ==========
  app.get("/api/hives", async (req, res) => {
    try {
      const apiaryId = req.query.apiaryId ? parseInt(req.query.apiaryId as string) : undefined;
      const hives = await storage.getHives(apiaryId);
      res.json(hives);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.get("/api/hives/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const hive = await storage.getHive(id);
      if (!hive) {
        return res.status(404).json({ error: "Hive not found" });
      }
      res.json(hive);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.post("/api/hives", async (req, res) => {
    try {
      const data = insertHiveSchema.parse(req.body);
      const hive = await storage.createHive(data);
      res.status(201).json(hive);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  app.patch("/api/hives/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const hive = await storage.updateHive(id, req.body);
      if (!hive) {
        return res.status(404).json({ error: "Hive not found" });
      }
      res.json(hive);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  app.delete("/api/hives/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const success = await storage.deleteHive(id);
      if (!success) {
        return res.status(404).json({ error: "Hive not found" });
      }
      res.status(204).send();
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // ========== Supers ==========
  app.get("/api/supers", async (req, res) => {
    try {
      const hiveId = parseInt(req.query.hiveId as string);
      if (!hiveId) {
        return res.status(400).json({ error: "hiveId is required" });
      }
      const supers = await storage.getSupers(hiveId);
      res.json(supers);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.post("/api/supers", async (req, res) => {
    try {
      const data = insertSuperSchema.parse(req.body);
      const superData = await storage.createSuper(data);
      res.status(201).json(superData);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  app.patch("/api/supers/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const superData = await storage.updateSuper(id, req.body);
      if (!superData) {
        return res.status(404).json({ error: "Super not found" });
      }
      res.json(superData);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  app.post("/api/supers/:id/remove", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const { removalReason, honeyHarvested } = req.body;
      const superData = await storage.removeSuper(id, removalReason, honeyHarvested);
      if (!superData) {
        return res.status(404).json({ error: "Super not found" });
      }
      res.json(superData);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  // ========== Inspections ==========
  app.get("/api/inspections", async (req, res) => {
    try {
      const hiveId = req.query.hiveId ? parseInt(req.query.hiveId as string) : undefined;
      const inspections = await storage.getInspections(hiveId);
      res.json(inspections);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.get("/api/inspections/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const inspection = await storage.getInspection(id);
      if (!inspection) {
        return res.status(404).json({ error: "Inspection not found" });
      }
      res.json(inspection);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.post("/api/inspections", async (req, res) => {
    try {
      const data = insertInspectionSchema.parse(req.body);
      const inspection = await storage.createInspection(data);
      res.status(201).json(inspection);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  // ========== Feeding ==========
  app.get("/api/feedings", async (req, res) => {
    try {
      const hiveId = req.query.hiveId ? parseInt(req.query.hiveId as string) : undefined;
      const feedings = await storage.getFeedings(hiveId);
      res.json(feedings);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.post("/api/feedings", async (req, res) => {
    try {
      const data = insertFeedingSchema.parse(req.body);
      const feeding = await storage.createFeeding(data);
      res.status(201).json(feeding);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  // ========== Royal Jelly ==========
  app.get("/api/royal-jelly", async (req, res) => {
    try {
      const hiveId = req.query.hiveId ? parseInt(req.query.hiveId as string) : undefined;
      const productions = await storage.getRoyalJellyProductions(hiveId);
      res.json(productions);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.post("/api/royal-jelly", async (req, res) => {
    try {
      const data = insertRoyalJellyProductionSchema.parse(req.body);
      const production = await storage.createRoyalJellyProduction(data);
      res.status(201).json(production);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  app.patch("/api/royal-jelly/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const production = await storage.updateRoyalJellyProduction(id, req.body);
      if (!production) {
        return res.status(404).json({ error: "Production not found" });
      }
      res.json(production);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  // ========== Pollen ==========
  app.get("/api/pollen", async (req, res) => {
    try {
      const hiveId = req.query.hiveId ? parseInt(req.query.hiveId as string) : undefined;
      const collections = await storage.getPollenCollections(hiveId);
      res.json(collections);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.post("/api/pollen", async (req, res) => {
    try {
      const data = insertPollenCollectionSchema.parse(req.body);
      const collection = await storage.createPollenCollection(data);
      res.status(201).json(collection);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  // ========== Honey Harvest ==========
  app.get("/api/honey-harvest", async (req, res) => {
    try {
      const hiveId = req.query.hiveId ? parseInt(req.query.hiveId as string) : undefined;
      const harvests = await storage.getHoneyHarvests(hiveId);
      res.json(harvests);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.post("/api/honey-harvest", async (req, res) => {
    try {
      const data = insertHoneyHarvestSchema.parse(req.body);
      const harvest = await storage.createHoneyHarvest(data);
      res.status(201).json(harvest);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  // ========== Queen Rearing ==========
  app.get("/api/queen-rearing", async (_req, res) => {
    try {
      const rearings = await storage.getQueenRearings();
      res.json(rearings);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.post("/api/queen-rearing", async (req, res) => {
    try {
      const data = insertQueenRearingSchema.parse(req.body);
      const rearing = await storage.createQueenRearing(data);
      res.status(201).json(rearing);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  app.patch("/api/queen-rearing/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const rearing = await storage.updateQueenRearing(id, req.body);
      if (!rearing) {
        return res.status(404).json({ error: "Rearing not found" });
      }
      res.json(rearing);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  // ========== Inventory ==========
  app.get("/api/inventory", async (_req, res) => {
    try {
      const items = await storage.getInventory();
      res.json(items);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.post("/api/inventory", async (req, res) => {
    try {
      const data = insertInventorySchema.parse(req.body);
      const item = await storage.createInventoryItem(data);
      res.status(201).json(item);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  app.patch("/api/inventory/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const item = await storage.updateInventoryItem(id, req.body);
      if (!item) {
        return res.status(404).json({ error: "Item not found" });
      }
      res.json(item);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  // ========== Sales ==========
  app.get("/api/sales", async (_req, res) => {
    try {
      const sales = await storage.getSales();
      res.json(sales);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.post("/api/sales", async (req, res) => {
    try {
      const data = insertSaleSchema.parse(req.body);
      const sale = await storage.createSale(data);
      res.status(201).json(sale);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  // ========== Alerts ==========
  app.get("/api/alerts", async (req, res) => {
    try {
      const unreadOnly = req.query.unreadOnly === 'true';
      const alerts = await storage.getAlerts(unreadOnly);
      res.json(alerts);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.post("/api/alerts", async (req, res) => {
    try {
      const data = insertAlertSchema.parse(req.body);
      const alert = await storage.createAlert(data);
      res.status(201).json(alert);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  app.patch("/api/alerts/:id/read", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const alert = await storage.markAlertAsRead(id);
      if (!alert) {
        return res.status(404).json({ error: "Alert not found" });
      }
      res.json(alert);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  // ========== Dashboard Stats ==========
  app.get("/api/dashboard/stats", async (_req, res) => {
    try {
      const hives = await storage.getHives();
      const alerts = await storage.getAlerts(true);
      
      const stats = {
        totalHives: hives.length,
        activeHives: hives.filter(h => h.isActive).length,
        alerts: alerts.length,
        expectedProduction: 450, // TODO: Calculate from actual data
      };
      
      res.json(stats);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
